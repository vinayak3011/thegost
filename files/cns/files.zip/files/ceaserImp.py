from ceaser import encode, decode
from filehelper import  read_from_file, write_to_file,appends_to_file

# text=input("Enter the text you want to cipher : ")
# offset=int(input("Enter the offset:"))
# en=encode(text,offset)
# print(f"\nCiphered Text: {en} ")
# de= decode(en,offset)
# print(f"\nDecoded Text: {de} ")

# Brute force encoded_text1=read_from_file(file_path="./College python/encoded_text_2.txt")
# off=int(1)
# while off<=128:
#     de=decode(encoded_text1,off)
#     print(f"\nDecoded Text: {de} offset : {off}\n")
#     off=off+1


# en=read_from_file(file_path="./College python/encoded_text_large.txt")
# # off=int(1)
# # # for off in range (1,128):
# de=decode(en,29)
# print(f"\nDecoded Text: {de} \noffset :")


